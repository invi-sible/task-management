import json
import pymongo
from bson.objectid import ObjectId

# Connect to the MongoDB database
client = pymongo.MongoClient("mongodb://localhost:27017")
db = client['taskdb']
tasks_collection = db['tasks']

# Helper function to convert MongoDB ObjectId to string
def task_to_dict(task):
    task['_id'] = str(task['_id'])  # Convert ObjectId to string
    return task

# GET: Fetch all tasks
def get_tasks(event, context):
    tasks = list(tasks_collection.find())
    tasks = [task_to_dict(task) for task in tasks]  # Convert ObjectIds
    return {
        'statusCode': 200,
        'body': json.dumps(tasks)
    }

# POST: Create a new task
def create_task(event, context):
    body = json.loads(event['body'])
    task = {
        'title': body['title'],
        'description': body['description'],
        'status': body['status']
    }
    result = tasks_collection.insert_one(task)
    task['_id'] = str(result.inserted_id)  # Add the MongoDB ID to the task
    return {
        'statusCode': 201,
        'body': json.dumps(task)
    }

# PUT: Update task status
def update_task(event, context):
    task_id = event['pathParameters']['id']
    body = json.loads(event['body'])
    updated_task = {
        'status': body['status']
    }
    tasks_collection.update_one({'_id': ObjectId(task_id)}, {'$set': updated_task})
    task = tasks_collection.find_one({'_id': ObjectId(task_id)})
    task = task_to_dict(task)  # Convert ObjectId to string
    return {
        'statusCode': 200,
        'body': json.dumps(task)
    }

# DELETE: Delete a task
def delete_task(event, context):
    task_id = event['pathParameters']['id']
    tasks_collection.delete_one({'_id': ObjectId(task_id)})
    return {
        'statusCode': 200,
        'body': json.dumps({'message': 'Task deleted successfully'})
    }
